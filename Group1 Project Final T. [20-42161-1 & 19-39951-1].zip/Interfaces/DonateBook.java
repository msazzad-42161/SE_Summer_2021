package Interfaces;

public interface DonateBook {
    void setCategory();
    void setBookInfo();
    void showBookInfo(String bookInformation);
    void writeDonationHistory(String bookInformation);
    void showDonationHistory();
}
